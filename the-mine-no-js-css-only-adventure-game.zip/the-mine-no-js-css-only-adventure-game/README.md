# The Mine: No JS, CSS only adventure game

A Pen created on CodePen.

Original URL: [https://codepen.io/AniPortal/pen/emJyeOP](https://codepen.io/AniPortal/pen/emJyeOP).

